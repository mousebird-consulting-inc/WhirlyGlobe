//
//  ViewController.h
//  WhirlyGlobeMicelloDemo
//
//  Created by Ranen Ghosh on 2016-04-14.
//  Copyright 2011-2016 mousebird consulting
//

#import <UIKit/UIKit.h>
#import <WhirlyGlobeComponent.h>

@interface ViewController : UIViewController <WhirlyGlobeViewControllerDelegate>

@end
